#!/bin/bash

set -e

DOCKER_NAME=rv1126-develop
VOL_SRC=${HOME}
VOL_TARGET=/opt
SYSROOT=/mnt
PKG_CONFIG_SYSROOT_DIR=$SYSROOT
PKG_CONFIG_PATH=$SYSROOT/usr/share/pkgconfig:$SYSROOT/usr/lib/arm-linux-gnueabihf/pkgconfig:$SYSROOT/usr/lib/pkgconfig:$PKG_CONFIG_PATH

function build_image()
{
	docker build --tag $DOCKER_NAME .
}

function build_container()
{	
	if [ $# -eq 2 ];
	then
		VOL_SRC=$1
		VOL_TARGET=$2
	fi

	docker run -dit \
		--hostname $DOCKER_NAME \
		--name $DOCKER_NAME \
		--privileged=true \
		--user=developer --workdir=/home/developer \
		--env VOL_SRC=${VOL_SRC} \
		--env VOL_TARGET=${VOL_TARGET} \
		--env DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
		--env SYSROOT=${SYSROOT} \
		--env PKG_CONFIG_SYSROOT_DIR=${PKG_CONFIG_SYSROOT_DIR} \
		--env PKG_CONFIG_PATH=${PKG_CONFIG_PATH} \
		-v $VOL_SRC:$VOL_TARGET \
		$DOCKER_NAME \
		/bin/bash
}

function main()
{
	## 创建镜像
	IMAGE_NUM=`docker images -a | grep "$DOCKER_NAME" | wc -l`
	if [ $IMAGE_NUM -eq 0 ];
	then
		build_image
	fi

	## 创建容器
	CONTAINER_NUM=`docker ps -a | grep "$DOCKER_NAME" | wc -l`
	if [ $CONTAINER_NUM -eq 0 ];
	then
		build_container $@
	fi

	## 进入容器
	docker start $DOCKER_NAME
	docker exec -it -e TERM=xterm-256color $DOCKER_NAME /usr/local/bin/start.sh
}

# 可带一个参数: -v host_path:container_path
main $@
