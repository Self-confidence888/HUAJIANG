#!/bin/bash

set -e

DOCKER_NAME=rv1126-develop

#如果要修改容器启动参数，可以执行本脚本删除名字为$DOCKER_NAME的容器、镜像，再重新执行run.sh脚本
docker stop $DOCKER_NAME
docker rm $DOCKER_NAME
docker rmi $DOCKER_NAME