#!/bin/bash

SOURCE_IP=192.168.253.2
SOURCE_TARGET_PATH="/"
SOURCE_TARGET=$SOURCE_IP:$SOURCE_TARGET_PATH
DEST_TARGET=${SYSROOT}
PID=$$
PID_DIR=/dev/shm/mount_nfs_pid
PID_FILE=""

function trap_handle()
{
	rm -f $PID_DIR/$PID
	exit 0
}

trap trap_handle SIGINT SIGTERM

if [ ! -e $PID_DIR ]; then
	mkdir -p $PID_DIR
fi
PID_FILE=`ls -A $PID_DIR`

if [ -n "$PID_FILE" ]; then # 非空表示有文件，退出
	exit 0
fi

touch $PID_DIR/$PID

while true
do
	MOUNTS=`mount | grep $DEST_TARGET | wc -l`
	if [ $MOUNTS -eq 0 ]; then
		sudo mount -t nfs $SOURCE_TARGET $DEST_TARGET -o nolock,timeo=10 > /dev/null
	fi
	sleep 1
done
