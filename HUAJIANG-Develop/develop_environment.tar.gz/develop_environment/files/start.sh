#!/bin/bash

if [ ! -e ${HOME}/.sudo_as_admin_successful ]; then
	touch ${HOME}/.sudo_as_admin_successful
fi
nohup mount-nfs.sh > /dev/null 2>&1 &

# display tips
echo
	if [ -e ${HOME}/configs/welcome.txt ]; then
		val="`cat ${HOME}/configs/welcome.txt`"
		val=$(echo "$val" | sed "s|/home/developer|$VOL_SRC|")
		echo "$val"
	fi
echo

/bin/bash -l
